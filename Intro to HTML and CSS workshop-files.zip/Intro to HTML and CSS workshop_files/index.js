(() => {
  var __commonJS = (callback, module) => () => {
    if (!module) {
      module = {exports: {}};
      callback(module.exports, module);
    }
    return module.exports;
  };

  // ns-hugo:/opt/build/repo/themes/tailwind-theme/assets/js/listeners.js
  var require_listeners = __commonJS(() => {
    document.addEventListener("DOMContentLoaded", (e) => {
      document.querySelectorAll("pre").forEach((pre) => new paperclip_default(pre));
      scroller_default.init();
    });
  });

  // ns-hugo:/opt/build/repo/themes/tailwind-theme/assets/js/components/paperclip.js
  var PaperClip = class {
    constructor(pre) {
      this.pre = pre;
      this.pre.appendChild(this.render());
    }
    copy() {
      let code = document.createElement("textarea");
      code.value = this.pre.textContent.trimEnd();
      this.pre.append(code);
      code.select();
      document.execCommand("copy");
      code.remove();
      this.changeClipColor("green");
      setTimeout(() => this.changeClipColor("white"), 3e3);
    }
    changeClipColor(color) {
      this.path ||= this.div.querySelector("path");
      this.path.setAttribute("fill", color);
    }
    render() {
      this.div = document.createElement("div");
      this.div.classList.add(..."absolute top-0 right-3".split(" "));
      this.div.innerHTML = `
    <svg 
        version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
        width="18px" height="18px" viewBox="0 0 950 950" style="enable-background:new 0 0 950 950; fill: 'white'; stroke: 'white';" xml:space="preserve"
        class="absolute top-2 right-0"
      >
      <g>
        <path d="M857.7,141.3c-30.1-30.1-65.1-53.5-104.3-69.4c-37.8-15.3-77.7-23.2-118.7-23.2c-40.9,0-80.9,7.7-118.7,22.9
          c-39.1,15.8-74.2,38.9-104.3,68.8L73.1,478.3C49.3,501.9,30.9,529.4,18.3,560.2C6.2,589.9,0,621.3,0,653.6
          C0,685.7,6.1,717,18.1,746.7c12.4,30.7,30.7,58.2,54.3,81.899c23.6,23.7,51.2,42,81.9,54.5c29.7,12.101,61.1,18.2,93.3,18.2
          c32.2,0,63.6-6.1,93.3-18.1c30.8-12.5,58.399-30.8,82.1-54.4l269.101-268c17.3-17.2,30.6-37.3,39.699-59.7
          c8.801-21.6,13.2-44.5,13.2-67.899c0-48.2-18.8-93.2-52.899-127c-34-34.2-79.2-53.1-127.301-53.3c-48.199-0.1-93.5,18.6-127.6,52.7
          L269.6,473.3c-8.5,8.5-13.1,19.7-13.1,31.601c0,11.899,4.6,23.199,13.1,31.6l0.7,0.7c17.4,17.5,45.8,17.5,63.3,0.1l168-167.5
          c35.1-34.8,92.1-35,127.199-0.399c16.9,16.8,26.101,39.3,26.101,63.399c0,24.3-9.4,47.101-26.5,64.101l-269,268
          c-0.5,0.5-0.9,0.899-1.2,1.5c-29.7,28.899-68.9,44.699-110.5,44.5c-41.9-0.2-81.2-16.5-110.6-46c-14.7-15-26.1-32.5-34-52
          C95.5,694,91.7,674,91.7,653.6c0-41.8,16.1-80.899,45.4-110.3c0.4-0.3,0.7-0.6,1.1-0.899l337.9-337.8c0.3-0.3,0.6-0.7,0.899-1.1
          c21.4-21,46.3-37.4,74-48.5c27-10.8,55.4-16.2,84.601-16.2c29.199,0,57.699,5.6,84.6,16.4c27.9,11.3,52.9,27.8,74.3,49.1
          c21.4,21.4,37.9,46.4,49.2,74.3c10.9,26.9,16.4,55.4,16.4,84.6c0,29.3-5.5,57.9-16.5,85c-11.301,28-28,53.2-49.5,74.8l-233.5,232.8
          c-8.5,8.5-13.2,19.7-13.2,31.7s4.7,23.2,13.1,31.6l0.5,0.5c17.4,17.4,45.8,17.4,63.2,0L857.5,586.9
          C887.601,556.8,911,521.7,926.9,482.6C942.3,444.8,950,404.9,950,363.9c0-40.9-7.8-80.8-23.1-118.5
          C911.101,206.3,887.8,171.3,857.7,141.3z" stroke="white" fill="white" class="transition duration-300 ease-out" />
      </g>
    </svg>
    `;
      this.div.onclick = () => this.copy();
      return this.div;
    }
  };
  var paperclip_default = PaperClip;

  // ns-hugo:/opt/build/repo/themes/tailwind-theme/assets/js/scroller.js
  var Scroller = class {
    static init() {
      if (document.querySelector(".tocLinks")) {
        this.tocLinks = document.querySelectorAll(".tocLinks a");
        this.tocLinks.forEach((link) => link.classList.add("transition", "duration-200"));
        this.headers = Array.from(this.tocLinks).map((link) => {
          return document.querySelector(`#${link.href.split("#")[1]}`);
        });
        this.ticking = false;
        window.addEventListener("scroll", (e) => {
          this.onScroll();
        });
      }
    }
    static onScroll() {
      if (!this.ticking) {
        requestAnimationFrame(this.update.bind(this));
        this.ticking = true;
      }
    }
    static update() {
      this.activeHeader ||= this.headers[0];
      let activeIndex = this.headers.findIndex((header) => {
        return header.getBoundingClientRect().top > 180;
      });
      if (activeIndex == -1) {
        activeIndex = this.headers.length - 1;
      } else if (activeIndex > 0) {
        activeIndex--;
      } else {
        this.tocLinks[0].classList.add("text-active");
      }
      let active = this.headers[activeIndex];
      if (active !== this.activeHeader) {
        this.activeHeader = active;
        this.tocLinks.forEach((link) => link.classList.remove("text-active"));
        this.tocLinks[activeIndex].classList.add("text-active");
      }
      this.ticking = false;
    }
  };
  var scroller_default = Scroller;

  // js/index.js
  require_listeners();
})();
